  
replace_all_na_with_minus1 <- function(data) {
  na_cols <- names(data)[colSums(is.na(data)) > 0]
  
  for (col in na_cols) {
    if (is.factor(data[[col]])) {
      data[[col]] <- as.character(data[[col]])
      data[[col]][is.na(data[[col]])] <- "-1"
      data[[col]] <- factor(data[[col]])
    } else {
      data[[col]][is.na(data[[col]])] <- -1
    }
  }
  
  return(data)
}

impute_daughters_from_mothers <- function(data, matches_df) {
  if (is.null(matches_df)) return(data)
  
  for (i in 1:nrow(matches_df)) {
    mother_col <- matches_df$mother[i]
    daughter_col <- matches_df$daughter[i]
    

    data[[mother_col]] <- as.character(data[[mother_col]])
    data[[daughter_col]] <- as.character(data[[daughter_col]])
    

    na_idx <- is.na(data[[daughter_col]])
    data[[daughter_col]][na_idx] <- data[[mother_col]][na_idx]
    

    data[[daughter_col]] <- factor(data[[daughter_col]])
  }
  
  return(data)
}


find_strict_mother_daughter <- function(data, valid_trigger_values = c("1", "2", "7", "8", "9")) {

  factor_cols <- names(data)[sapply(data, is.factor)]
  
  mother_candidates <- factor_cols[
    sapply(data[factor_cols], function(col) {
      all(!is.na(col)) && all(levels(col) %in% valid_trigger_values)
    })
  ]
  
  matching_pairs <- list()
  
  for (mother in mother_candidates) {
    trigger_vals <- as.character(data[[mother]])
    is_trigger_1 <- trigger_vals == "1"
    
    for (candidate in setdiff(factor_cols, mother)) {
      target_vals <- data[[candidate]]
      is_na_target <- is.na(target_vals)
      
      if (all(is_na_target == !is_trigger_1)) {
        matching_pairs[[length(matching_pairs) + 1]] <- c(mother = mother, daughter = candidate)
      }
    }
  }
  
  if (length(matching_pairs) > 0) {
    result_df <- as.data.frame(do.call(rbind, matching_pairs), stringsAsFactors = FALSE)
    print(result_df)
    return(result_df)
  } else {
    return(NULL)
  }
}
  
impute_daughters_from_mothers <- function(data, matches_df) {
  if (is.null(matches_df)) return(data)
  
  for (i in 1:nrow(matches_df)) {
    mother_col <- matches_df$mother[i]
    daughter_col <- matches_df$daughter[i]
    
    data[[mother_col]] <- as.character(data[[mother_col]])
    data[[daughter_col]] <- as.character(data[[daughter_col]])
    
    na_idx <- is.na(data[[daughter_col]])
    data[[daughter_col]][na_idx] <- data[[mother_col]][na_idx]
    
    data[[daughter_col]] <- factor(data[[daughter_col]])
  }
  
  cat( "Valori imputati nelle figlie dove erano NA, usando i valori delle madri.\n")
  return(data)
}
  
normalize_unknown_values <- function(data, exceptions_keep = c("CVDVAC1Y1_A", "HICOSTR1_A")) {
  for (col in names(data)) {
    col_data <- data[[col]]
    

    if (is.factor(col_data) && !(col %in% exceptions_keep)) {
      col_vec <- as.character(col_data)
      col_vec[col_vec %in% c("7", "8", "9", "-1")] <- "Unknown"
      data[[col]] <- factor(col_vec)
      

    } 
      if (col == "HICOSTR1_A") {
        data[[col]][data[[col]] %in% c(99997, 99998, 99999)] <- "Unknown"
      } else if (col != "CVDVAC1Y1_A") {
        data[[col]][data[[col]] %in% c(-1, 9997, 9998, 9999)] <- "Unknown"
      
    }
  }
  
  return(data)
}


remove_high_unknown_columns <- function(data, threshold = 0.30, unknown_label = "Unknown") {
  cat_vars <- names(data)[sapply(data, function(col) is.factor(col) || is.character(col))]
  cols_to_remove <- c()
  
  for (var in cat_vars) {
    vals <- as.character(data[[var]])
    total <- length(vals)
    
    unknown_count <- sum(vals == unknown_label, na.rm = TRUE)
    perc <- unknown_count / total
    
    if (!is.na(perc) && perc > threshold) {
      cols_to_remove <- c(cols_to_remove, var)
      message(sprintf("Column '%s' removed: %.2f%% unknown values", var, perc * 100))
    }
  }
  
  data_clean <- data[, !(names(data) %in% cols_to_remove)]
  return(data_clean)
}



 

  
semantic_conf_matrix <- function(trigger, target, match_vals) {
  trigger_vals <- ifelse(data[[trigger]] %in% match_vals, "SI", "ALTRO")
  target_vals <- ifelse(is.na(data[[target]]), "NA", "Risposto")
  
  cat("\nConfusion Matrix per:", trigger, "->", target, "con match su", paste(match_vals, collapse = ", "), "\n")
  print(table(Trigger = trigger_vals, Target = target_vals))
}

 

  
dataset_summary <- function(data) {
  n_rows <- nrow(data)
  n_cols <- ncol(data)
  
  var_classes <- sapply(data, function(x) class(x)[1])
  
  cat_vars <- names(data)[var_classes %in% c("factor", "character")]
  num_vars <- names(data)[var_classes %in% c("numeric", "integer")]
  
  num_cat <- length(cat_vars)
  num_num <- length(num_vars)
  
  cat("Dataset summary:\n")
  cat("- Total rows:", n_rows, "\n")
  cat("- Total columns:", n_cols, "\n")
  cat("- Categorical variables:", num_cat, "\n")
  cat("- Numerical variables:", num_num, "\n\n")
  
  if (num_cat > 0) {
    cat("List of categorical variables:\n")
    print(cat_vars)
  }
  
  if (num_num > 0) {
    cat("\nList of numerical variables:\n")
    print(num_vars)
  }
}

  
summary_categorical_variables <- function(data, max_levels = 5, digits = 2) {
  cat_vars <- names(data)[sapply(data, function(col) is.factor(col) || is.character(col))]
  
  summary_list <- lapply(cat_vars, function(var) {
    values <- data[[var]]
    freq_table <- table(values, useNA = "ifany")
    total <- length(values)
    na_perc <- round(sum(is.na(values)) / total * 100, digits)
    top_levels <- names(sort(freq_table, decreasing = TRUE))[1:min(max_levels, length(freq_table))]
    
    data.frame(
      Variable = var,
      Num_Levels = length(unique(values)),
      Top_Levels = paste(top_levels, collapse = ", "),
      Most_Common = names(freq_table[which.max(freq_table)]),
      Most_Common_Count = max(freq_table),
      NA_Percent = na_perc,
      stringsAsFactors = FALSE
    )
  })
  
  summary_df <- do.call(rbind, summary_list)
  summary_df <- summary_df[order(-summary_df$NA_Percent), ]
  return(summary_df)
}

 

  
find_dependent_targets <- function(data, trigger_var, value_filter = c(1)) {
  if (!(trigger_var %in% names(data))) {
    cat("Trigger column not found in dataset:", trigger_var, "\n")
    return(NULL)
  }
  
  trigger_vals <- data[[trigger_var]]
  target_candidates <- names(data)[names(data) != trigger_var]
  matched_targets <- c()
  
  for (target_col in target_candidates) {
    target_vals <- data[[target_col]]
    
    num_na <- sum(is.na(target_vals))
    num_trigger_not_in_filter <- sum(!(trigger_vals %in% value_filter), na.rm = TRUE)
    
    if (!is.na(num_na) && num_na == num_trigger_not_in_filter) {
      matched_targets <- c(matched_targets, target_col)
    }
  }
  
  if (length(matched_targets) == 0) {
    cat("No dependent columns found for", trigger_var, "with value(s):", paste(value_filter, collapse = ","), "\n")
    return(NULL)
  } else {
    cat("\n Dependent target columns found:\n")
    print(matched_targets)
    return(matched_targets)
  }
}

plot_confusion_matrices <- function(data, trigger_var, target_vars) {
  if (is.null(target_vars) || length(target_vars) == 0) {
    cat("No target variables provided for confusion matrix.\n")
    return()
  }
  
  for (target_col in target_vars) {
    if (target_col %in% names(data)) {
      cat("\n📊 Confusion Matrix:", target_col, "vs", trigger_var, "\n")
      print(table(data[[target_col]], data[[trigger_var]], useNA = "ifany"))
    } else {
      cat("Column not found in dataset:", target_col, "\n")
    }
  }
}

confusion_value_vs_na <- function(data, trigger_var, target_var, value_filter = c(1)) {
  if (!(trigger_var %in% names(data)) || !(target_var %in% names(data))) {
    cat("Column not found in dataset.\n")
    return(NULL)
  }
  
  trigger_vals <- data[[trigger_var]]
  target_vals <- data[[target_var]]
  
  # Crea due variabili logiche:
  # - trigger_in_filter: TRUE se il valore è nel filtro, FALSE altrimenti
  # - target_is_na: TRUE se NA, FALSE altrimenti
  trigger_in_filter <- trigger_vals %in% value_filter
  target_is_na <- is.na(target_vals)
  
  # Costruisce la confusion matrix
  conf_matrix <- table(TriggerInFilter = trigger_in_filter, TargetIsNA = target_is_na)
  
  cat("\nConfusion Matrix (", target_var, "~ is.na vs", trigger_var, "in", paste(value_filter, collapse = ","), "):\n")
  print(conf_matrix)
  return(conf_matrix)
}

find_perfect_matches <- function(data, no_na_cols, has_1_2_no_na) {
  with_na_cols <- names(data)[!no_na_cols]
  cols_1_2 <- names(data)[has_1_2_no_na]
  
  perfect_match <- list()
  
  for (trigger_col in cols_1_2) {
    is_one <- data[[trigger_col]] == 1
    
    for (target_col in with_na_cols) {
      num_na <- sum(is.na(data[[target_col]]))
      num_not_1 <- sum(!is_one)
      
      if (num_na == num_not_1) {
        perfect_match[[length(perfect_match) + 1]] <- c(trigger = trigger_col, target = target_col)
      }
    }
  }
  
  if (length(perfect_match) > 0) {
    match_df <- as.data.frame(do.call(rbind, perfect_match), stringsAsFactors = FALSE)
    print(match_df)
    return(match_df)
  } else {
    return(NULL)
  }
}

impute_from_triggers <- function(data, matches) {
  if (is.null(matches)) return(data)
  
  colnames(matches) <- c("Trigger", "Target")
  
  for (i in 1:nrow(matches)) {
    trig <- matches$Trigger[i]
    targ <- matches$Target[i]
    
    if (is.factor(data[[targ]])) data[[targ]] <- as.character(data[[targ]])
    if (is.factor(data[[trig]])) data[[trig]] <- as.character(data[[trig]])
    
    na_idx <- is.na(data[[targ]])
    data[[targ]][na_idx] <- data[[trig]][na_idx]
  }
  return(data)
}

find_dependent_vars <- function(data, trigger_var, trigger_val) {
  dependent_vars <- c()
  is_trigger_yes <- data[[trigger_var]] == trigger_val
  
  for (colname in names(data)) {
    if (colname == trigger_var) next
    
    col_data <- data[[colname]]
    if (all(is.na(col_data[!is_trigger_yes])) && any(!is.na(col_data[is_trigger_yes]))) {
      dependent_vars <- c(dependent_vars, colname)
    }
  }
  
  return(dependent_vars)
}

na_summary <- function(data) {
  total_cols <- ncol(data)
  total_rows <- nrow(data)
  
  cols_with_na <- sum(sapply(data, function(col) any(is.na(col))))
  cols_without_na <- total_cols - cols_with_na
  
  cat("Total number of columns:", total_cols, "\n")
  cat("Columns with at least one missing value:", cols_with_na, "\n")
  cat("Columns without missing values:", cols_without_na, "\n")
  cat("Total number of rows:", total_rows, "\n")
}


analyze_column_uniqueness <- function(data) {
  total_rows <- nrow(data)
  unique_counts <- sapply(data, function(x) length(unique(x)))

  constant_columns <- names(unique_counts[unique_counts == 1])
  

  unique_value_columns <- names(unique_counts[unique_counts == total_rows])
  
  for (col in constant_columns) {
    value <- unique(data[[col]])
    cat(col, ":", value, "\n")
  }
  
  print(unique_value_columns)
}

clean_and_integer <- function(x, colname) {
  x <- as.character(x)
  special_codes <- c("7", "8", "9", "97", "98", "99", "07", "08", "09")
  x[x %in% special_codes] <- NA 
  x_num <- suppressWarnings(as.integer(x))
  if (any(is.na(x_num) & !is.na(x))) {
    cat("Residual non-numeric values in column:", colname, "\n")
  }
  return(x_num)
}

show_residual_na <- function(data) {
  n <- nrow(data)
  na_summary <- sapply(data, function(x) sum(is.na(x)))
  na_cols <- na_summary[na_summary > 0]
  
  if (length(na_cols) == 0) {
    return(invisible(NULL))
  }
  
  na_df <- data.frame(
    Colonna = names(na_cols),
    N_NA = na_cols,
    Percentuale = round(100 * na_cols / n, 2)
  )
  
  print(na_df)
  
  return(na_df)
}

check_imputed_targets <- function(data, matches) {
  if (is.null(matches)) {
    return(NULL)
  }
  
  colnames(matches) <- c("Trigger", "Target")
  remaining_na <- sapply(matches$Target, function(col) sum(is.na(data[[col]])))
  
  result_df <- data.frame(
    Target = matches$Target,
    Remaining_NA = remaining_na,
    stringsAsFactors = FALSE
  )
  print(result_df)
  return(result_df)
}



 
